package com.nu_CS4520_group9.shelfmate.fakes

import androidx.paging.PagingSource
import com.nu_CS4520_group9.shelfmate.data.local.BookEntity

class FakePagingSource(
    private val data: List<BookEntity>
) : PagingSource<Int, BookEntity>() {
    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, BookEntity> {
        val start = params.key ?: 0
        val end = minOf(start + params.loadSize, data.size)
        val sublist = data.subList(start, end)
        return LoadResult.Page(
            data = sublist,
            prevKey = if (start == 0) null else start - params.loadSize,
            nextKey = if (end == data.size) null else end
        )
    }

    override fun getRefreshKey(state: androidx.paging.PagingState<Int, BookEntity>): Int? {
        return 0
    }
}