package com.nu_CS4520_group9.shelfmate.repository

import androidx.paging.testing.asSnapshot
import com.nu_CS4520_group9.shelfmate.data.local.BookEntity
import com.nu_CS4520_group9.shelfmate.data.repository.BookRepository
import com.nu_CS4520_group9.shelfmate.fakes.FakeBookDao
import com.nu_CS4520_group9.shelfmate.fakes.FakeShelfmateApiService
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import kotlinx.coroutines.flow.first

class BookRepositoryTest {

    private lateinit var fakeBookDao: FakeBookDao
    private lateinit var fakeApiService: FakeShelfmateApiService
    private lateinit var repository: BookRepository

    @Before
    fun setup() {
        fakeBookDao = FakeBookDao()
        fakeApiService = FakeShelfmateApiService()
        repository = BookRepository(fakeApiService, fakeBookDao)
    }

    @Test
    fun `getBooksPagingData returns correct mapped books`() = runTest {

        val entities = listOf(
            BookEntity("111", 1,"Title 1", "Author 1", "Desc 1", null, false),
            BookEntity("222", 2,"Title 2", "Author 2", "Desc 2", "Note", true),
            BookEntity("333", 3, "Title 3", "Author 3", "Desc 3", null, false)
        )
        fakeBookDao.insertBooks(entities)

        val pagingData = repository.getBooksPagingData()
        val booksList = pagingData.asSnapshot()
        // Assert – verify the list size and some field values.
        assertEquals(3, booksList.size)
        assertEquals("111", booksList[0].isbn)
        assertEquals("222", booksList[1].isbn)
        assertEquals("333", booksList[2].isbn)
    }

    @Test
    fun `getBookmarkedBooks returns only bookmarked books`() = runTest {
        // Arrange – insert data with mixed bookmark flags.
        val entities = listOf(
            BookEntity("111", 1,"Title 1", "Author 1", "Desc 1", null, false),
            BookEntity("222", 2,"Title 2", "Author 2", "Desc 2", "Note", true),
            BookEntity("333",3, "Title 3", "Author 3", "Desc 3", null, true)
        )
        fakeBookDao.insertBooks(entities)
        // Act
        val bookmarked = repository.getBookmarkedBooks().first()
        // Assert
        assertEquals(2, bookmarked.size)
        assertTrue(bookmarked.all { it.bookmarked })
    }

    @Test
    fun `getBookByIsbn returns correct book`() = runTest {
        // Arrange
        val entity = BookEntity("111",1,"Title 1", "Author 1", "Desc 1", null, false)
        fakeBookDao.insertBooks(listOf(entity))
        // Act
        val book = repository.getBookByIsbn("111").first()
        // Assert
        assertEquals("111", book.isbn)
        assertEquals("Title 1", book.title)
    }

    @Test
    fun `updateNoteForBook updates note`() = runTest {
        // Arrange
        val entity = BookEntity("111",1, "Title 1", "Author 1", "Desc 1", null, false)
        fakeBookDao.insertBooks(listOf(entity))
        // Act
        repository.updateNoteForBook("111", "Updated Note")
        // Assert – check the DAO’s data directly.
        val updatedEntity = fakeBookDao.getBookByIsbnDirect("111")
        assertEquals("Updated Note", updatedEntity?.note)
    }

    @Test
    fun `updateBookmark updates bookmark status`() = runTest {
        // Arrange
        val entity = BookEntity("111",1, "Title 1", "Author 1", "Desc 1", null, false)
        fakeBookDao.insertBooks(listOf(entity))
        // Act
        repository.updateBookmark("111", true)
        // Assert
        val updatedEntity = fakeBookDao.getBookByIsbnDirect("111")
        assertTrue(updatedEntity?.bookmarked == true)
    }

    @Test
    fun `clearBookmarkedBooks removes bookmarked books`() = runTest {

        val entities = listOf(
            BookEntity("111",1,"Title 1", "Author 1", "Desc 1", null, true),
            BookEntity("222",2, "Title 2", "Author 2", "Desc 2", "Note", true),
            BookEntity("333",3, "Title 3", "Author 3", "Desc 3", null, false)
        )
        fakeBookDao.insertBooks(entities)

        repository.clearBookmarkedBooks()

        val count = fakeBookDao.countBooks()
        assertEquals(1, count)
        val remaining = fakeBookDao.books
        assertTrue(remaining.all { !it.bookmarked })
    }
}