package com.nu_CS4520_group9.shelfmate.fakes

import com.nu_CS4520_group9.shelfmate.data.model.PagedBookResponse
import com.nu_CS4520_group9.shelfmate.data.model.RawBook
import com.nu_CS4520_group9.shelfmate.data.remote.ShelfmateApiService
import retrofit2.Response

class FakeShelfmateApiService : ShelfmateApiService {
    override suspend fun getBooks(lastIsbn: String?, pageSize: Int): Response<PagedBookResponse> {
        // Return a fake response. (In these tests, the dao is the source of truth.)
        val rawBooks = listOf(
            RawBook(1, "1234", "Title 1", "Author 1", "Desc 1"),
            RawBook(2, "1235", "Title 2", "Author 2", "Desc 2")
        )
        val response = PagedBookResponse(rawBooks, pagination = PagedBookResponse.Pagination(
            totalBooks = 2,
            totalPages = 1,
            currentPage = 1,
            pageSize = 2,
            hasNext = false,
            hasPrevious = false
        )
        )
        return Response.success(response)
    }
}