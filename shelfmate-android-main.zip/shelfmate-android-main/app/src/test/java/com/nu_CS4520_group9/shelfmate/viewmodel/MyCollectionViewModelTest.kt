package com.nu_CS4520_group9.shelfmate.viewmodel

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.nu_CS4520_group9.shelfmate.data.model.Book
import com.nu_CS4520_group9.shelfmate.fakes.FakeBookRepository
import com.nu_CS4520_group9.shelfmate.ui.my_collection.MyCollectionViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class MyCollectionViewModelTest {

    @get:Rule
    val instantExecutorRule = InstantTaskExecutorRule()

    private lateinit var fakeRepository: FakeBookRepository
    private lateinit var viewModel: MyCollectionViewModel

    @Before
    fun setup() {
        Dispatchers.setMain(UnconfinedTestDispatcher())
        fakeRepository = FakeBookRepository()
        // Arrange – add books with different bookmark statuses.
        val books = listOf(
            Book("111", "Title 1", "Author 1", "Desc 1", null, true),
            Book("222", "Title 2", "Author 2", "Desc 2", null, false),
            Book("333", "Title 3", "Author 3", "Desc 3", null, true)
        )
        fakeRepository.addBooks(books)
        viewModel = MyCollectionViewModel(fakeRepository)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `bookmarkedBooks emits only bookmarked books`() = runTest {

        val bookmarked = viewModel.bookmarkedBooks.first()

        assertEquals(2, bookmarked.size)
        assertTrue(bookmarked.all { it.bookmarked })
    }
}