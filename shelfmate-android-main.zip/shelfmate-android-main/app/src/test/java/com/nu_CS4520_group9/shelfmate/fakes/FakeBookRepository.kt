package com.nu_CS4520_group9.shelfmate.fakes

import com.nu_CS4520_group9.shelfmate.data.model.Book
import com.nu_CS4520_group9.shelfmate.data.repository.IBookRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flowOf

class FakeBookRepository : IBookRepository {
    private val books = mutableListOf<Book>()
    private val bookmarkedBooksFlow = MutableStateFlow<List<Book>>(emptyList())
    // For getBookByIsbn, we hold a map of flows.
    private val bookFlowMap = mutableMapOf<String, MutableStateFlow<Book>>()

    // Helper to add fake books
    fun addBooks(list: List<Book>) {
        books.addAll(list)
        bookmarkedBooksFlow.value = books.filter { it.bookmarked }
        list.forEach { book ->
            bookFlowMap[book.isbn] = MutableStateFlow(book)
        }
    }

    override fun getBooksPagingData(): Flow<androidx.paging.PagingData<Book>> {
        // Create a PagingData from the list using PagingData.from()
        val pagingData = androidx.paging.PagingData.from(books)
        return flowOf(pagingData)
    }

    override fun getBookmarkedBooks(): Flow<List<Book>> = bookmarkedBooksFlow

    override fun getBookByIsbn(isbn: String): Flow<Book> {
        return bookFlowMap[isbn] ?: MutableStateFlow(Book(isbn, "Unknown", "Unknown", "Unknown", null, false))
    }

    override suspend fun updateNoteForBook(isbn: String, note: String) {
        val index = books.indexOfFirst { it.isbn == isbn }
        if (index != -1) {
            val book = books[index]
            val updatedBook = book.copy(note = note)
            books[index] = updatedBook
            bookmarkedBooksFlow.value = books.filter { it.bookmarked }
            bookFlowMap[isbn]?.value = updatedBook
        }
    }

    override suspend fun updateBookmark(isbn: String, bookmarked: Boolean) {
        val index = books.indexOfFirst { it.isbn == isbn }
        if (index != -1) {
            val book = books[index]
            val updatedBook = book.copy(bookmarked = bookmarked)
            books[index] = updatedBook
            bookmarkedBooksFlow.value = books.filter { it.bookmarked }
            bookFlowMap[isbn]?.value = updatedBook
        }
    }

    override suspend fun clearBookmarkedBooks() {
        books.removeAll { it.bookmarked }
        bookmarkedBooksFlow.value = books.filter { it.bookmarked }
    }
}