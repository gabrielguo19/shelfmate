package com.nu_CS4520_group9.shelfmate.fakes

import com.nu_CS4520_group9.shelfmate.data.local.BookDao
import kotlinx.coroutines.flow.Flow
import com.nu_CS4520_group9.shelfmate.data.local.BookEntity
import com.nu_CS4520_group9.shelfmate.data.model.RawBook
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flow

class FakeBookDao : BookDao {

    // Maintain an in-memory list for testing.
    val books = mutableListOf<BookEntity>()
    private val bookmarkedBooksFlow = MutableStateFlow<List<BookEntity>>(emptyList())

    override fun getBooksPagingSource(): androidx.paging.PagingSource<Int, BookEntity> {
        return FakePagingSource(books)
    }

    override fun getBookmarkedBooks(): Flow<List<BookEntity>> = bookmarkedBooksFlow

    override fun getBookByIsbn(isbn: String): Flow<BookEntity> = flow {
        emit(books.first { it.isbn == isbn })
    }

    override suspend fun getBookByIsbnDirect(isbn: String): BookEntity? {
        return books.firstOrNull { it.isbn == isbn }
    }

    override suspend fun insert(book: BookEntity) {
        if (books.any { it.isbn == book.isbn }) return
        books.add(book)
        updateFlows()
    }

    override suspend fun update(book: BookEntity) {
        val index = books.indexOfFirst { it.isbn == book.isbn }
        if (index != -1) {
            books[index] = book
        }
        updateFlows()
    }

    override suspend fun updateBookmark(isbn: String, bookmarked: Boolean) {
        val index = books.indexOfFirst { it.isbn == isbn }
        if (index != -1) {
            val book = books[index]
            books[index] = book.copy(bookmarked = bookmarked)
        }
        updateFlows()
    }

    override suspend fun updateNote(isbn: String, note: String) {
        val index = books.indexOfFirst { it.isbn == isbn }
        if (index != -1) {
            val book = books[index]
            books[index] = book.copy(note = note)
        }
        updateFlows()
    }

    override suspend fun deleteStaleBooks(isbns: List<String>) {
        books.removeAll { it.isbn !in isbns && !it.bookmarked && (it.note.isNullOrBlank()) }
        updateFlows()
    }

    override suspend fun upsertBooks(newBooks: List<BookEntity>) {
        newBooks.forEach { newBook ->
            val index = books.indexOfFirst { it.isbn == newBook.isbn }
            if (index == -1) {
                books.add(newBook)
            } else {
                val existingBook = books[index]
                books[index] = newBook.copy(note = existingBook.note, bookmarked = existingBook.bookmarked)
            }
        }
        updateFlows()
    }

    override suspend fun updateBooksFromApi(rawBooks: List<RawBook>, isRefresh: Boolean) {
        if (isRefresh) {
            val newIsbns = rawBooks.map { it.isbn }
            deleteStaleBooks(newIsbns)
        }
        val newEntities = rawBooks.map { BookEntity.fromApi(it) }
        upsertBooks(newEntities)
    }

    override suspend fun countBooks(): Int = books.size

    override suspend fun clearBookmarkedBooks() {
        books.removeAll { it.bookmarked }
        updateFlows()
    }

    /** Helper: Insert a list of books. */
    fun insertBooks(newBooks: List<BookEntity>) {
        books.addAll(newBooks)
        updateFlows()
    }

    private fun updateFlows() {
        bookmarkedBooksFlow.value = books.filter { it.bookmarked }
    }
}