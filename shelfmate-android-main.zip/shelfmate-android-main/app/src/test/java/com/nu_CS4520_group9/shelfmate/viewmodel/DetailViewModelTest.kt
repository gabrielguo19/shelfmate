package com.nu_CS4520_group9.shelfmate.viewmodel

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.nu_CS4520_group9.shelfmate.ui.detail.DetailUiState
import com.nu_CS4520_group9.shelfmate.ui.detail.DetailViewModel
import com.nu_CS4520_group9.shelfmate.data.model.Book
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import com.nu_CS4520_group9.shelfmate.fakes.FakeBookRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After

@OptIn(ExperimentalCoroutinesApi::class)
class DetailViewModelTest {

    @get:Rule
    val instantExecutorRule = InstantTaskExecutorRule()

    private lateinit var fakeRepository: FakeBookRepository
    private lateinit var viewModel: DetailViewModel
    private val testBook = Book("111", "Title 1", "Author 1", "Desc 1", null, false)

    @Before
    fun setup() {
        Dispatchers.setMain(UnconfinedTestDispatcher())
        fakeRepository = FakeBookRepository()
        fakeRepository.addBooks(listOf(testBook))
        viewModel = DetailViewModel(fakeRepository, "111")
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `when book is loaded then state is Success`() = runTest {
        // Act & Assert – wait until the UI state changes to Success.
        val state = viewModel.book.first { it is DetailUiState.Success }
        if (state is DetailUiState.Success) {
            assertEquals(testBook, state.book)
        }
    }

    @Test
    fun `toggleBookmark updates bookmark state`() = runTest {
        // Act – toggle the bookmark.
        viewModel.toggleBookmark()
        // Assert – verify that the book’s bookmarked flag is updated.
        val updatedState = viewModel.book.first { it is DetailUiState.Success }
        if (updatedState is DetailUiState.Success) {
            assertTrue(updatedState.book.bookmarked)
        }
    }

    @Test
    fun `updateNote changes the note of a book`() = runTest {
        // Act – update the note.
        viewModel.updateNote("New Note")
        // Assert – check that the book now has the new note.
        val updatedState = viewModel.book.first { it is DetailUiState.Success && it.book.note == "New Note" }
        if (updatedState is DetailUiState.Success) {
            assertEquals("New Note", updatedState.book.note)
        }
    }

    @Test
    fun `updateNote does not update if note is blank`() = runTest {
        // Capture the current note.
        val initialState = viewModel.book.first { it is DetailUiState.Success } as DetailUiState.Success
        // Act – attempt to update with a blank note.
        viewModel.updateNote("   ") // only whitespace – should be ignored.
        // Assert – the note remains unchanged.
        val stateAfter = viewModel.book.first { it is DetailUiState.Success }
        if (stateAfter is DetailUiState.Success) {
            assertEquals(initialState.book.note, stateAfter.book.note)
        }
    }
}