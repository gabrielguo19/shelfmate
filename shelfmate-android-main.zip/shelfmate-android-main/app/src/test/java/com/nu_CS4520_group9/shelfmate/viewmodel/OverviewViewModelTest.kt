package com.nu_CS4520_group9.shelfmate.viewmodel

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.paging.testing.asSnapshot
import com.nu_CS4520_group9.shelfmate.data.model.Book
import com.nu_CS4520_group9.shelfmate.ui.overview.OverviewViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import org.junit.Before
import org.junit.Rule
import com.nu_CS4520_group9.shelfmate.fakes.FakeBookRepository
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class OverviewViewModelTest {

    @get:Rule
    val instantExecutorRule = InstantTaskExecutorRule()

    private lateinit var fakeRepository: FakeBookRepository
    private lateinit var viewModel: OverviewViewModel

    @Before
    fun setup() {
        // Set the main dispatcher for unit tests.
        Dispatchers.setMain(UnconfinedTestDispatcher())
        fakeRepository = FakeBookRepository()
        // Arrange – add some fake books.
        val fakeBooks = listOf(
            Book("111", "Title 1", "Author 1", "Desc 1", null, false),
            Book("222", "Title 2", "Author 2", "Desc 2", "Note", true),
            Book("333", "Title 3", "Author 3", "Desc 3", null, false)
        )
        fakeRepository.addBooks(fakeBooks)
        viewModel = OverviewViewModel(fakeRepository)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `booksPagingData emits expected books`() = runTest {
        val pagingData = viewModel.booksPagingData
        val items = pagingData.asSnapshot()

        assertEquals(3, items.size)
        assertEquals("111", items[0].isbn)
        assertEquals("222", items[1].isbn)
        assertEquals("333", items[2].isbn)
    }
}