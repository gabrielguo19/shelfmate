package com.nu_CS4520_group9.shelfmate.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

data class RemoteKeyEntity(
    @PrimaryKey val id: String, // Use a constant key since we have one paging query.
    val nextKey: String? // This stores the ISBN of the last book from the previous API response.
)
