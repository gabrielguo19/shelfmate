package com.nu_CS4520_group9.shelfmate.data.model

import com.google.gson.annotations.SerializedName

data class PagedBookResponse(
    val books: List<RawBook>,
    val pagination: Pagination,
) {
    data class Pagination(
        @SerializedName("total_books")
        val totalBooks: Int,

        @SerializedName("total_pages")
        val totalPages: Int,

        @SerializedName("current_page")
        val currentPage: Int,

        @SerializedName("page_size")
        val pageSize: Int,

        @SerializedName("has_next")
        val hasNext: Boolean,

        @SerializedName("has_previous")
        val hasPrevious: Boolean
    )
}