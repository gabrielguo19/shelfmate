package com.nu_CS4520_group9.shelfmate.ui.settings

import ThemeManager
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.MutableCreationExtras
import androidx.navigation.NavHostController
import com.nu_CS4520_group9.shelfmate.data.local.AppDatabase
import com.nu_CS4520_group9.shelfmate.data.remote.ShelfmateApiService
import com.nu_CS4520_group9.shelfmate.data.remote.ShelfmateRetrofitBuilder
import com.nu_CS4520_group9.shelfmate.data.repository.BookRepository
import kotlinx.coroutines.launch
import androidx.room.Room

@Composable
fun SettingsScreen(
    navController: NavHostController,
    themeManager: ThemeManager
) {
    val context = LocalContext.current

    val apiService = ShelfmateRetrofitBuilder
        .getRetrofit()
        .create(ShelfmateApiService::class.java)
    val db = Room.databaseBuilder(
        context,
        AppDatabase::class.java,
        "books-database"
    ).build()
    val repository = BookRepository(apiService, db.bookDao())

    val extras = MutableCreationExtras()
    extras[SettingsViewModel.BOOK_REPOSITORY_KEY] = repository

    val viewModel: SettingsViewModel = viewModel(
        factory = SettingsViewModel.Factory,
        extras = extras
    )

    val coroutineScope = rememberCoroutineScope()
    val isDarkTheme by themeManager.isDarkTheme.collectAsState(initial = false)
    var showSupportDialog by remember { mutableStateOf(false) }
    var showClearDialog by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(32.dp)
        ) {
            // Theme Toggle
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Brightness6, contentDescription = "Theme")
                Spacer(Modifier.width(16.dp))
                Text("Dark Mode", modifier = Modifier.weight(1f))
                Switch(
                    checked = isDarkTheme,
                    onCheckedChange = {
                        coroutineScope.launch {
                            themeManager.toggleTheme()
                        }
                    }
                )
            }

            // Support Button
            Button(
                onClick = { showSupportDialog = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Phone, contentDescription = "Support")
                Spacer(Modifier.width(8.dp))
                Text("Support")
            }

            // Clear Data Button
            Button(
                onClick = { showClearDialog = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Delete, contentDescription = "Clear Data")
                Spacer(Modifier.width(8.dp))
                Text("Clear My Collection")
            }
        }

        // Support Dialog
        if (showSupportDialog) {
            AlertDialog(
                onDismissRequest = { showSupportDialog = false },
                title = { Text("Support") },
                text = { Text("Call us at 1-800-555-BOOK") },
                confirmButton = {
                    TextButton(onClick = { showSupportDialog = false }) {
                        Text("OK")
                    }
                }
            )
        }

        // Clear Data Confirmation Dialog
        if (showClearDialog) {
            AlertDialog(
                onDismissRequest = { showClearDialog = false },
                title = { Text("Clear My Collection") },
                text = { Text("Are you sure you want to remove all books from your collection?") },
                confirmButton = {
                    TextButton(onClick = {
                        showClearDialog = false
                        viewModel.clearBookmarkedBooks()
                        scope.launch {
                            snackbarHostState.showSnackbar(
                                "All books removed from your collection."
                            )
                        }
                    }) {
                        Text("Yes")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showClearDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}
