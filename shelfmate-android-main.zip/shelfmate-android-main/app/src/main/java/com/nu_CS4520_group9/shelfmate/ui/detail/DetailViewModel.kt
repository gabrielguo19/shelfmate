package com.nu_CS4520_group9.shelfmate.ui.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.nu_CS4520_group9.shelfmate.data.model.Book
import com.nu_CS4520_group9.shelfmate.data.repository.BookRepository
import com.nu_CS4520_group9.shelfmate.data.repository.IBookRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class DetailViewModel(
    private val repository: IBookRepository,
    private val isbn: String
) : ViewModel() {
    // Change from product to book.
    private val _book = MutableStateFlow<DetailUiState>(DetailUiState.Loading)
    val book: StateFlow<DetailUiState> = _book

    init {
        loadBook()
    }

    private fun loadBook() {
        viewModelScope.launch {
            try {
                repository.getBookByIsbn(isbn).collect { book ->
                    _book.value = DetailUiState.Success(book)
                }
            } catch (e: Exception) {
                _book.value = DetailUiState.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun toggleBookmark() {
        viewModelScope.launch {
            val currentBook = (book.value as? DetailUiState.Success)?.book
            currentBook?.let {
                repository.updateBookmark(it.isbn, !it.bookmarked)
            }
        }
    }

    fun updateNote(note: String) {
        if (note.isBlank()) return // Do not save if the note is empty or only whitespace
        viewModelScope.launch {
            repository.updateNoteForBook(isbn, note)
        }
    }

    companion object {
        // Define a custom key for your dependency.
        val BOOK_REPOSITORY_KEY = object : CreationExtras.Key<BookRepository> {}
        val PRODUCT_ID_KEY = object : CreationExtras.Key<String> {}

        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val myRepository = this[BOOK_REPOSITORY_KEY] as BookRepository
                val productId = this[PRODUCT_ID_KEY] as String
                DetailViewModel(
                    repository = myRepository,
                    isbn = productId
                )
            }
        }
    }
}

// UI state for the detail screen.
sealed class DetailUiState {
    data object Loading : DetailUiState()
    data class Error(val message: String) : DetailUiState()
    data class Success(val book: Book) : DetailUiState()
}
