package com.nu_CS4520_group9.shelfmate.data.repository

import androidx.paging.ExperimentalPagingApi
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.map
import com.nu_CS4520_group9.shelfmate.data.local.BookDao
import com.nu_CS4520_group9.shelfmate.data.model.Book
import com.nu_CS4520_group9.shelfmate.data.remote.ShelfmateApiService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class BookRepository(
    private val apiService: ShelfmateApiService,
    private val bookDao: BookDao
) : IBookRepository {
    // Returns paginated books mapped to the domain model.
    @OptIn(ExperimentalPagingApi::class)
    override fun getBooksPagingData(): Flow<PagingData<Book>> {
        return Pager(
            config = PagingConfig(pageSize = 20, enablePlaceholders = false),
            remoteMediator = BookRemoteMediator(apiService, bookDao),
            pagingSourceFactory = { bookDao.getBooksPagingSource() }
        ).flow
            .map { pagingData ->
                pagingData.map { entity ->
                    Book(
                        isbn = entity.isbn,
                        title = entity.title,
                        author = entity.author,
                        description = entity.description,
                        note = entity.note,
                        bookmarked = entity.bookmarked
                    )
                }
            }
    }

    // Returns bookmarked books as a Flow.
    override fun getBookmarkedBooks(): Flow<List<Book>> {
        return bookDao.getBookmarkedBooks().map { entities ->
            entities.map { entity ->
                Book(
                    isbn = entity.isbn,
                    title = entity.title,
                    author = entity.author,
                    description = entity.description,
                    note = entity.note,
                    bookmarked = entity.bookmarked
                )
            }
        }
    }

    // Returns a single book by ISBN as a Flow.
    override fun getBookByIsbn(isbn: String): Flow<Book> {
        return bookDao.getBookByIsbn(isbn).map { entity ->
            Book(
                isbn = entity.isbn,
                title = entity.title,
                author = entity.author,
                description = entity.description,
                note = entity.note,
                bookmarked = entity.bookmarked
            )
        }
    }

    // New function to update the note for a book.
    override suspend fun updateNoteForBook(isbn: String, note: String) {
        bookDao.updateNote(isbn, note)
    }

    override suspend fun updateBookmark(isbn: String, bookmarked: Boolean) {
        bookDao.updateBookmark(isbn, bookmarked)
    }

    override suspend fun clearBookmarkedBooks() {
        bookDao.clearBookmarkedBooks()
    }
}