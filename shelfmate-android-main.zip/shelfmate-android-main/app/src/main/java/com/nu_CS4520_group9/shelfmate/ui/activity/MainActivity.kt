package com.nu_CS4520_group9.shelfmate.ui.activity

import ThemeManager
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import androidx.work.BackoffPolicy
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.nu_CS4520_group9.shelfmate.ProductRefreshWorker
import com.nu_CS4520_group9.shelfmate.ui.navigation.AppNavHost
import com.nu_CS4520_group9.shelfmate.ui.navigation.ShelfmateBottomNavigation
import com.nu_CS4520_group9.shelfmate.ui.theme.ShelfmateTheme
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private lateinit var themeManager: ThemeManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize theme manager
        themeManager = ThemeManager(this)

        scheduleProductRefresh(this)

        enableEdgeToEdge()
        setContent {
            // Collect theme state
            val isDarkTheme by themeManager.isDarkTheme.collectAsState(initial = false)

            ShelfmateTheme(darkTheme = isDarkTheme) {
                AppContent(themeManager = themeManager)
            }
        }
    }

    @Composable
    private fun AppContent(themeManager: ThemeManager) {
        val navController = rememberNavController()

        Scaffold(bottomBar = {
            ShelfmateBottomNavigation(navController = navController)
        }) { innerPadding ->
            AppNavHost(
                navController = navController,
                modifier = Modifier.padding(innerPadding),
                themeManager = themeManager
            )
        }
    }

    private fun scheduleProductRefresh(context: Context) {
        val refreshWorkRequest = PeriodicWorkRequestBuilder<ProductRefreshWorker>(
            repeatInterval = 1,
            repeatIntervalTimeUnit = TimeUnit.HOURS
        )
            .setInitialDelay(1, TimeUnit.HOURS)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 1, TimeUnit.MINUTES)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "ProductRefreshWork",
            ExistingPeriodicWorkPolicy.UPDATE,
            refreshWorkRequest
        )
    }
}
