package com.nu_CS4520_group9.shelfmate.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.nu_CS4520_group9.shelfmate.data.repository.BookRepository
import kotlinx.coroutines.launch

// SettingsViewModel.kt
class SettingsViewModel(
    private val repository: BookRepository
) : ViewModel() {

    fun clearBookmarkedBooks() {
        viewModelScope.launch {
            repository.clearBookmarkedBooks()
        }
    }

    companion object {
        val BOOK_REPOSITORY_KEY = object : CreationExtras.Key<BookRepository> {}

        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val repository = this[BOOK_REPOSITORY_KEY] as BookRepository
                SettingsViewModel(repository)
            }
        }
    }
}