package com.nu_CS4520_group9.shelfmate.data.local

import androidx.room.*
import com.nu_CS4520_group9.shelfmate.data.model.RawBook

@Entity
data class BookEntity(
    @PrimaryKey val isbn: String,
    val index: Int,
    val title: String,
    val author: String,
    val description: String,
    val note: String?,
    val bookmarked: Boolean = false,
) {
    companion object {
        fun fromApi(book: RawBook): BookEntity {
            return BookEntity(
                isbn = book.isbn,
                index = book.index,
                title = book.title,
                author = book.author,
                description = book.description,
                note = null,
            )
        }
    }

}

