import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.themeDataStore by preferencesDataStore(name = "theme_settings")

class ThemeManager(context: Context) {
    companion object {
        private val DARK_THEME_KEY = booleanPreferencesKey("dark_theme_enabled")
    }

    private val dataStore = context.themeDataStore

    val isDarkTheme: Flow<Boolean> = dataStore.data
        .map { preferences: Preferences ->
            preferences[DARK_THEME_KEY] ?: false
        }

    suspend fun toggleTheme() {
        dataStore.edit { preferences ->
            val current = preferences[DARK_THEME_KEY] ?: false
            preferences[DARK_THEME_KEY] = !current
        }
    }
}
