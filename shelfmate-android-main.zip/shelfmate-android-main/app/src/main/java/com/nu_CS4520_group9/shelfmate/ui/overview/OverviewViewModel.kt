package com.nu_CS4520_group9.shelfmate.ui.overview

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.nu_CS4520_group9.shelfmate.data.model.Book
import com.nu_CS4520_group9.shelfmate.data.repository.BookRepository
import com.nu_CS4520_group9.shelfmate.data.repository.IBookRepository
import kotlinx.coroutines.flow.*

class OverviewViewModel(
    private val repository: IBookRepository
) : ViewModel() {

    val booksPagingData: Flow<PagingData<Book>> =
        repository.getBooksPagingData().cachedIn(viewModelScope)

    // Define ViewModel factory in a companion object
    // See https://developer.android.com/topic/libraries/architecture/viewmodel/viewmodel-factories#creationextras_custom
    companion object {

        // Define a custom key for your dependency
        val BOOK_REPOSITORY_KEY = object : CreationExtras.Key<BookRepository> {}

        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                // Get the dependency in your factory
                val myRepository = this[BOOK_REPOSITORY_KEY] as BookRepository
                OverviewViewModel(
                    repository = myRepository,
                )
            }
        }
    }
}