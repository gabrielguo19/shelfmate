package com.nu_CS4520_group9.shelfmate.ui.my_collection

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.MutableCreationExtras
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.paging.LoadState
import androidx.paging.compose.collectAsLazyPagingItems
import androidx.room.Room
import com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi
import com.bumptech.glide.integration.compose.GlideImage
import com.nu_CS4520_group9.shelfmate.R
import com.nu_CS4520_group9.shelfmate.data.local.AppDatabase
import com.nu_CS4520_group9.shelfmate.data.remote.ShelfmateApiService
import com.nu_CS4520_group9.shelfmate.data.remote.ShelfmateRetrofitBuilder
import com.nu_CS4520_group9.shelfmate.data.repository.BookRepository
import com.nu_CS4520_group9.shelfmate.data.model.Book

@Composable
fun MyCollectionScreen(navController: NavHostController) {
    val viewModel: MyCollectionViewModel = viewModel(
        factory = MyCollectionViewModel.Factory,
        extras = MutableCreationExtras().apply {
            val context = LocalContext.current

            val shelfmateApiService = ShelfmateRetrofitBuilder
                .getRetrofit()
                .create(ShelfmateApiService::class.java)
            val db = Room.databaseBuilder(context, AppDatabase::class.java, "books-database").build()
            val bookDao = db.bookDao()
            val repository = BookRepository(shelfmateApiService, bookDao)

            set(MyCollectionViewModel.BOOK_REPOSITORY_KEY, repository)
        }
    )

    // Collect the PagingData as LazyPagingItems.
    val bookmarkedBooks by viewModel.bookmarkedBooks.collectAsState(initial = emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        TitleCard()

        if (bookmarkedBooks.isEmpty()) {
            MessageContent(message = "No bookmarked books")
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(bookmarkedBooks.size) { index ->
                    val book = bookmarkedBooks[index]
                    BookCard(book = book) {
                        navController.navigate("detail/${book.isbn}")
                    }
                }
            }
        }
    }
}


// Title card at the top of the screen
@Composable
private fun TitleCard() {
    ElevatedCard(
        colors = CardDefaults.cardColors(
            containerColor = colorResource(R.color.teal_700),
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Text(
            text = stringResource(R.string.my_collection_title),
            modifier = Modifier.padding(16.dp),
            style = MaterialTheme.typography.headlineSmall,
            color = Color.Black
        )
    }
}

// A composable that displays a centered message with an optional retry button.
@Composable
private fun MessageContent(message: String,onRetry: (() -> Unit)? = null) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = message,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium
        )
        onRetry?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = onRetry) {
                Text(text = stringResource(id = R.string.retry_button_text))
            }
        }
    }
}

// Individual product card
@OptIn(ExperimentalGlideComposeApi::class)
@Composable
fun BookCard(book: Book, onClick: () -> Unit) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() } // Make the card clickable
    ) {
        Column {
            GlideImage(
                model = book.imageUrlLarge,
                contentDescription = "Book cover",
                contentScale = ContentScale.FillBounds,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp) // or your dimensionResource
            )
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Cyan)
                    .padding(8.dp)
            ) {
                Text(
                    text = book.title,
                    style = MaterialTheme.typography.headlineSmall,
                    maxLines = 1
                )
                Text(
                    text = book.author,
                    style = MaterialTheme.typography.labelMedium,
                    maxLines = 1
                )
                Text(
                    text = book.isbn,
                    style = MaterialTheme.typography.labelMedium,
                    maxLines = 1
                )
            }
        }
    }
}
