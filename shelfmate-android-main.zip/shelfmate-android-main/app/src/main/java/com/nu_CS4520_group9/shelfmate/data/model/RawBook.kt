package com.nu_CS4520_group9.shelfmate.data.model

data class RawBook(
    val index: Int,
    val isbn: String,
    val title: String,
    val author: String,
    val description: String
)