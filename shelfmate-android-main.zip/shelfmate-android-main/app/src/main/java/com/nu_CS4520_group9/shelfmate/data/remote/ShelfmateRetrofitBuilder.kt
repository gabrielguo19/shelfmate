package com.nu_CS4520_group9.shelfmate.data.remote

import android.content.Context
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ShelfmateRetrofitBuilder {

    private lateinit var retrofit: Retrofit
    private const val BASE_URL = "https://shelfmate.pythonanywhere.com/"

    fun getRetrofit(): Retrofit {
        if (!this::retrofit.isInitialized) {
            retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            return retrofit
        }

        return retrofit
    }
}