package com.nu_CS4520_group9.shelfmate

import android.content.Context
import androidx.room.Room
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.nu_CS4520_group9.shelfmate.data.local.AppDatabase
import com.nu_CS4520_group9.shelfmate.data.local.BookEntity
import com.nu_CS4520_group9.shelfmate.data.remote.ShelfmateApiService
import com.nu_CS4520_group9.shelfmate.data.remote.ShelfmateRetrofitBuilder

class ProductRefreshWorker(
    context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    private val shelfmateApiService = ShelfmateRetrofitBuilder
        .getRetrofit()
        .create(ShelfmateApiService::class.java)
    private val productDao = Room
        .databaseBuilder(context, AppDatabase::class.java, "products-database")
        .build()
        .bookDao()

    override suspend fun doWork(): Result {
        return try {
            for (page in 1..5) {
                val response = shelfmateApiService.getBooks(null)
                if (response.isSuccessful) {
                    response.body()?.let { pagedResponse ->
                        productDao.updateBooksFromApi(pagedResponse.books, isRefresh = true)
                    }
                } else {
                    return Result.retry()
                }
            }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}