package com.nu_CS4520_group9.shelfmate.ui.navigation

import ThemeManager
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.nu_CS4520_group9.shelfmate.ui.detail.DetailScreen
import com.nu_CS4520_group9.shelfmate.ui.my_collection.MyCollectionScreen
import com.nu_CS4520_group9.shelfmate.ui.overview.OverviewScreen
import com.nu_CS4520_group9.shelfmate.ui.settings.SettingsScreen

enum class TabScreen {
    OVERVIEW,
    DETAIL,
    SETTINGS,
    MY_COLLECTION
}

sealed class TabItem(val route: String, val icon: ImageVector, val title: String) {
    data object Overview : TabItem(TabScreen.OVERVIEW.name, Icons.Filled.Home, "Overview")
    data object Detail : TabItem(TabScreen.DETAIL.name, Icons.Filled.Home, "Detail") {
        fun createRoute(isbn: String): String = "$route/$isbn"
    }
    data object MyCollection : TabItem(TabScreen.MY_COLLECTION.name, Icons.Filled.Book, "My Collection")
    data object Settings : TabItem(TabScreen.SETTINGS.name, Icons.Filled.Settings, "Settings")

    // List of all tab items.
    companion object {
        val items = listOf(Overview, MyCollection, Settings)
    }
}

@Composable
fun AppNavHost(
    navController: NavHostController,
    startDestination: String = TabItem.Overview.route,
    modifier: Modifier,
    themeManager: ThemeManager
) {
    NavHost(
        navController = navController,
        startDestination = startDestination,
        modifier = modifier
    ) {
        composable(TabItem.Overview.route) {
            OverviewScreen(navController)
        }
        composable(TabItem.MyCollection.route) {
            MyCollectionScreen(navController)
        }
        composable(TabItem.Settings.route) {
            SettingsScreen(
                navController = navController,
                themeManager = themeManager
            )
        }

        composable(
            TabItem.Detail.route + "/{isbn}",
            arguments = listOf(navArgument("isbn") { type = NavType.StringType })
        ) { backStackEntry ->
            val isbn = backStackEntry.arguments?.getString("isbn")
            DetailScreen(productId = isbn, navController = navController)
        }
    }
}
