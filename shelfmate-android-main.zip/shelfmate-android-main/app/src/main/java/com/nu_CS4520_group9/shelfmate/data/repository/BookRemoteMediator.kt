package com.nu_CS4520_group9.shelfmate.data.repository

import androidx.paging.ExperimentalPagingApi
import androidx.paging.LoadType
import androidx.paging.PagingState
import androidx.paging.RemoteMediator
import com.nu_CS4520_group9.shelfmate.data.local.BookDao
import com.nu_CS4520_group9.shelfmate.data.local.BookEntity
import com.nu_CS4520_group9.shelfmate.data.remote.ShelfmateApiService

// https://developer.android.com/topic/libraries/architecture/paging/v3-network-db
// https://developer.android.com/reference/kotlin/androidx/paging/RemoteMediator
@OptIn(ExperimentalPagingApi::class)
class BookRemoteMediator(
    private val apiService: ShelfmateApiService,
    private val bookDao: BookDao
) : RemoteMediator<Int, BookEntity>() {

    override suspend fun initialize(): InitializeAction {
        val count = bookDao.countBooks()
        return if (count > 0) {
            // If we have cached books, load data in the background.
            InitializeAction.SKIP_INITIAL_REFRESH
        } else {
            InitializeAction.LAUNCH_INITIAL_REFRESH
        }
    }

    override suspend fun load(
        loadType: LoadType,
        state: PagingState<Int, BookEntity>
    ): MediatorResult {
        try {
            // Determine the key for the next load.
            val lastIsbn: String? = when (loadType) {
                LoadType.REFRESH -> null  // Fetch the first page.
                LoadType.PREPEND -> return MediatorResult.Success(endOfPaginationReached = true)
                LoadType.APPEND -> {
                    val lastItem = state.lastItemOrNull()
                    lastItem?.isbn ?: return MediatorResult.Success(endOfPaginationReached = true)
                }
            }

            // Perform the API call.
            val response = apiService.getBooks(lastIsbn, state.config.pageSize)
            if (response.isSuccessful) {
                val pagedResponse = response.body()
                    ?: return MediatorResult.Success(endOfPaginationReached = true)
                val newBooks = pagedResponse.books

                // Here’s the new check using the `index` field:
                if (loadType == LoadType.APPEND) {
                    val lastItem = state.lastItemOrNull()
                    // If the first item in the newly loaded list does not have a higher index
                    // than the last cached item then the API returned a page that is identical
                    // (or older) => end pagination.
                    if (newBooks.isNotEmpty() &&
                        lastItem != null &&
                        newBooks.first().index <= lastItem.index
                    ) {
                        return MediatorResult.Success(endOfPaginationReached = true)
                    }
                }

                // Determine if there is more data based on the API's response.
                val endOfPaginationReached = !pagedResponse.pagination.hasNext

                // Update the database cache:
                // This function will insert new records or update existing ones (but keep
                // bookmark and note fields from local changes).
                bookDao.updateBooksFromApi(newBooks, loadType == LoadType.REFRESH)

                return MediatorResult.Success(endOfPaginationReached = endOfPaginationReached)
            } else {
                return MediatorResult.Error(Exception("API call failed with code: ${response.code()}"))
            }
        } catch (e: Exception) {
            return MediatorResult.Error(e)
        }
    }
}

