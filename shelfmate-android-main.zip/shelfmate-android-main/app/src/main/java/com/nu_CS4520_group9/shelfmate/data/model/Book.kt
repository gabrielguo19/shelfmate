package com.nu_CS4520_group9.shelfmate.data.model

data class Book(
    val isbn: String,
    val title: String,
    val author: String,
    val description: String,
    val note: String?,
    val bookmarked: Boolean,

    // Computed property to calculate the image URL in the
    val imageUrlLarge: String = "https://covers.openlibrary.org/b/isbn/$isbn-L.jpg",
    val imageUrlSmall: String = "https://covers.openlibrary.org/b/isbn/$isbn-S.jpg"
)