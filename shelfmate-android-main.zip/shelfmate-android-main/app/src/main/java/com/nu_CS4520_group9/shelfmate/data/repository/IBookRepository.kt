package com.nu_CS4520_group9.shelfmate.data.repository

import androidx.paging.PagingData
import com.nu_CS4520_group9.shelfmate.data.model.Book
import kotlinx.coroutines.flow.Flow

interface IBookRepository {
    fun getBooksPagingData(): Flow<PagingData<Book>>
    fun getBookmarkedBooks(): Flow<List<Book>>
    fun getBookByIsbn(isbn: String): Flow<Book>
    suspend fun updateNoteForBook(isbn: String, note: String)
    suspend fun updateBookmark(isbn: String, bookmarked: Boolean)
    suspend fun clearBookmarkedBooks()
}