package com.nu_CS4520_group9.shelfmate.ui.overview

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.MutableCreationExtras
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.paging.LoadState
import androidx.paging.compose.collectAsLazyPagingItems
import androidx.room.Room
import com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi
import com.bumptech.glide.integration.compose.GlideImage
import com.nu_CS4520_group9.shelfmate.R
import com.nu_CS4520_group9.shelfmate.data.local.AppDatabase
import com.nu_CS4520_group9.shelfmate.data.remote.ShelfmateApiService
import com.nu_CS4520_group9.shelfmate.data.remote.ShelfmateRetrofitBuilder
import com.nu_CS4520_group9.shelfmate.data.repository.BookRepository
import com.nu_CS4520_group9.shelfmate.data.model.Book
import com.nu_CS4520_group9.shelfmate.ui.navigation.TabItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OverviewScreen(
    navController: NavHostController,
) {
    val viewModel: OverviewViewModel = viewModel(
        factory = OverviewViewModel.Factory,
        extras = MutableCreationExtras().apply {
            val context = LocalContext.current

            val shelfmateApiService = ShelfmateRetrofitBuilder
                .getRetrofit()
                .create(ShelfmateApiService::class.java)
            val db = Room.databaseBuilder(context, AppDatabase::class.java, "books-database").build()
            val bookDao = db.bookDao()
            val repository = BookRepository(shelfmateApiService, bookDao)

            set(OverviewViewModel.BOOK_REPOSITORY_KEY, repository)
        }
    )

    // Collect the PagingData as LazyPagingItems.
    val lazyPagingItems = viewModel.booksPagingData.collectAsLazyPagingItems()

    // Add a Scaffold with a TopAppBar.
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Overview") }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                when {
                    lazyPagingItems.loadState.refresh is LoadState.Loading -> {
                        // Centered loading indicator
                        CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                    }
                    lazyPagingItems.loadState.refresh is LoadState.Error -> {
                        val error = lazyPagingItems.loadState.refresh as LoadState.Error
                        MessageContent(
                            message = "Failed to load books: ${error.error.localizedMessage}",
                            onRetry = { lazyPagingItems.retry() }
                        )
                    }
                    lazyPagingItems.itemCount == 0 -> {
                        MessageContent(
                            message = stringResource(R.string.no_books_found),
                        )
                    }
                    else -> {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) {
                            items(lazyPagingItems.itemCount) { index ->
                                lazyPagingItems[index]?.let { product ->
                                    ProductListItem(
                                        product = product,
                                        onClick = {
                                            navController.navigate(TabItem.Detail.createRoute(product.isbn))
                                        }
                                    )
                                    HorizontalDivider()
                                }
                            }

                            // Append a loading indicator when more pages are being loaded.
                            if (lazyPagingItems.loadState.append is LoadState.Loading) {
                                item {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        CircularProgressIndicator()
                                    }
                                }
                            }

                            // Append an error message when more pages fail to load.
                            if (lazyPagingItems.loadState.append is LoadState.Error) {
                                item {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        val error = lazyPagingItems.loadState.append as LoadState.Error
                                        MessageContent(
                                            message = "Failed to load books: ${error.error.localizedMessage}",
                                            onRetry = { lazyPagingItems.retry() }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// A composable that displays a centered message with an optional retry button
@Composable
private fun MessageContent(message: String, onRetry: (() -> Unit)? = null) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = message,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium
        )
        onRetry?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = onRetry) {
                Text(text = stringResource(id = R.string.retry_button_text))
            }
        }
    }
}

// List item for displaying products in a row format instead of cards
@OptIn(ExperimentalGlideComposeApi::class)
@Composable
fun ProductListItem(product: Book, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Image on left
        GlideImage(
            model = product.imageUrlSmall,
            contentDescription = "Product image",
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(64.dp)
        )

        // Text details on right
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(text = product.title, style = MaterialTheme.typography.titleMedium)
            // Secondary information
            Text(
                text = product.author,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
