package com.nu_CS4520_group9.shelfmate.ui.my_collection

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.nu_CS4520_group9.shelfmate.data.model.Book
import com.nu_CS4520_group9.shelfmate.data.repository.BookRepository
import com.nu_CS4520_group9.shelfmate.data.repository.IBookRepository
import kotlinx.coroutines.flow.*

class MyCollectionViewModel(
    private val repository: IBookRepository
) : ViewModel() {
    // Change from booksPagingData to bookmarkedBooks
    val bookmarkedBooks: Flow<List<Book>> = repository.getBookmarkedBooks()


    companion object {
        val BOOK_REPOSITORY_KEY = object : CreationExtras.Key<BookRepository> {}

        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {

                val myRepository = this[BOOK_REPOSITORY_KEY] as BookRepository
                MyCollectionViewModel(repository = myRepository)

            }
        }
    }
}

