package com.nu_CS4520_group9.shelfmate.data.local

import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.nu_CS4520_group9.shelfmate.data.model.RawBook
import kotlinx.coroutines.flow.Flow

@Dao
interface BookDao {

    // PagingSource for the paginated list: now ordered by index.
    @Query("SELECT * FROM BookEntity ORDER BY `index` ASC")
    fun getBooksPagingSource(): PagingSource<Int, BookEntity>

    // Flow of bookmarked books.
    @Query("SELECT * FROM BookEntity WHERE bookmarked = 1")
    fun getBookmarkedBooks(): Flow<List<BookEntity>>

    // Flow of a single book based on its ISBN.
    @Query("SELECT * FROM BookEntity WHERE isbn = :isbn LIMIT 1")
    fun getBookByIsbn(isbn: String): Flow<BookEntity>

    // Direct query (non-Flow) to help with upsert operations.
    @Query("SELECT * FROM BookEntity WHERE isbn = :isbn LIMIT 1")
    suspend fun getBookByIsbnDirect(isbn: String): BookEntity?

    // Insert a single book, ignoring conflicts.
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(book: BookEntity)

    // Update an existing book.
    @Update
    suspend fun update(book: BookEntity)

    @Query("UPDATE BookEntity SET bookmarked = :bookmarked WHERE isbn = :isbn")
    suspend fun updateBookmark(isbn: String, bookmarked: Boolean)

    // New function: update the note.
    @Query("UPDATE BookEntity SET note = :note WHERE isbn = :isbn")
    suspend fun updateNote(isbn: String, note: String)

    // Upsert operation: insert if not existing; update preserving note and bookmark if it exists.
    @Transaction
    suspend fun upsertBooks(newBooks: List<BookEntity>) {
        newBooks.forEach { newBook ->
            val existingBook = getBookByIsbnDirect(newBook.isbn)
            if (existingBook == null) {
                insert(newBook)
            } else {
                val updatedBook = newBook.copy(
                    note = existingBook.note,
                    bookmarked = existingBook.bookmarked
                )
                update(updatedBook)
            }
        }
    }

    // Remove records that are not in the list of provided ISBNs,
    // but only delete those that are unbookmarked and have no note.
    @Query("DELETE FROM BookEntity WHERE isbn NOT IN (:isbns) AND bookmarked = 0 AND (note IS NULL OR note = '')")
    suspend fun deleteStaleBooks(isbns: List<String>)

    // New function that wraps the deletion and upsert in a transaction.
    // The isRefresh flag determines whether to delete stale books (only on refresh).
    @Transaction
    suspend fun updateBooksFromApi(rawBooks: List<RawBook>, isRefresh: Boolean) {
        if (isRefresh) {
            val newIsbns = rawBooks.map { it.isbn }
            deleteStaleBooks(newIsbns)
        }
        val newEntities = rawBooks.map { BookEntity.fromApi(it) }
        upsertBooks(newEntities)
    }

    @Query("SELECT COUNT(*) FROM BookEntity")
    suspend fun countBooks(): Int

    // Clear bookmarks
    @Query("DELETE FROM BookEntity WHERE bookmarked = 1")
    suspend fun clearBookmarkedBooks()
}

