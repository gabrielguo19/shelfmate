package com.nu_CS4520_group9.shelfmate.data.remote

import com.nu_CS4520_group9.shelfmate.data.model.PagedBookResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface ShelfmateApiService {
    @GET("api/books")
    suspend fun getBooks(
        @Query("lastIsbn") lastIsbn: String? = null,
        @Query("pageSize") pageSize: Int = 20
    ): Response<PagedBookResponse>
}