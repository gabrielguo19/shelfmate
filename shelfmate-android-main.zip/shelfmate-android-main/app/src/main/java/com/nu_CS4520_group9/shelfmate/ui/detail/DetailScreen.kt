package com.nu_CS4520_group9.shelfmate.ui.detail

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.MutableCreationExtras
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi
import com.bumptech.glide.integration.compose.GlideImage
import com.nu_CS4520_group9.shelfmate.data.local.AppDatabase
import androidx.room.Room
import com.nu_CS4520_group9.shelfmate.data.remote.ShelfmateApiService
import com.nu_CS4520_group9.shelfmate.data.remote.ShelfmateRetrofitBuilder
import com.nu_CS4520_group9.shelfmate.data.repository.BookRepository

@OptIn(ExperimentalMaterial3Api::class, ExperimentalGlideComposeApi::class)
@Composable
fun DetailScreen(
    productId: String?,
    navController: NavHostController,
) {
    val viewModel: DetailViewModel = viewModel(
        factory = DetailViewModel.Factory,
        extras = MutableCreationExtras().apply {
            val context = LocalContext.current

            val shelfmateApiService = ShelfmateRetrofitBuilder
                .getRetrofit()
                .create(ShelfmateApiService::class.java)
            val db = Room.databaseBuilder(context, AppDatabase::class.java, "books-database").build()
            val bookDao = db.bookDao()
            val repository = BookRepository(shelfmateApiService, bookDao)

            set(DetailViewModel.BOOK_REPOSITORY_KEY, repository)
            set(DetailViewModel.PRODUCT_ID_KEY, productId ?: "")
        }
    )

    val productState by viewModel.book.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Detail") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    val currentBook = (productState as? DetailUiState.Success)?.book
                    IconButton(onClick = { viewModel.toggleBookmark() }) {
                        Icon(
                            if (currentBook?.bookmarked == true) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Bookmark"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        when (val uiState = productState) {
            is DetailUiState.Loading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
            is DetailUiState.Error -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Error: ${uiState.message}")
                }
            }
            is DetailUiState.Success -> {
                val product = uiState.book
                // Local mutable state for note editing.
                var noteText by remember { mutableStateOf(product.note ?: "") }
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(16.dp)
                ) {
                    // Book cover image.
                    GlideImage(
                        model = product.imageUrlLarge,
                        contentDescription = "Book cover",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Title
                    Text(
                        text = product.title,
                        style = MaterialTheme.typography.headlineSmall
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Author
                    Text(
                        text = "Author: ${product.author}",
                        style = MaterialTheme.typography.bodyLarge
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // ISBN
                    Text(
                        text = product.isbn,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Description",
                        style = MaterialTheme.typography.titleMedium
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = product.description,
                        style = MaterialTheme.typography.bodyMedium,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Note editing area.
                    Text(
                        text = "My Note",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    TextField(
                        value = noteText,
                        onValueChange = { noteText = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Enter your note here") }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { viewModel.updateNote(noteText) },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Save Note")
                    }
                }
            }
        }
    }
}
