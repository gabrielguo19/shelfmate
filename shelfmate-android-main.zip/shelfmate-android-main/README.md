# Shelfmate - Group 9 - Final Project
**CS4520 - Mobile Application Development**
*Students:*
- Alessio Nossa ([nossa.a@northeastern.edu](mailto:nossa.a@northeastern.edu))
- Gabriel Guo ([guo.ga@northeastern.edu](mailto:nossa.a@northeastern.edu))


### How to run the project

In order to build and run the project:

- Open the project with Android Studio
- Wait for Gradle to Sync
- Build and run the app on an Virtual Device or on a physical one